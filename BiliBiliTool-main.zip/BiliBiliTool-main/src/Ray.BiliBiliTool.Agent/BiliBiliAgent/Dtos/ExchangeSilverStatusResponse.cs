﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class ExchangeSilverStatusResponse
    {
        public int Silver { get; set; }
    }
}
