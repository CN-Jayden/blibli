﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ray.BiliBiliTool.Config.Options
{
    public class PushOptions
    {
        public string PushScKey { get; set; }
    }
}
